from botocore.exceptions import ClientError
from exceptions import ScannerError


def scan(session, region="us-east-1"):
    resources = []
    try:
        ec2 = session.client("ec2", region_name=region)
        paginator = ec2.get_paginator("describe_snapshots")
        for page in paginator.paginate(OwnerIds=["self"]):
            for snap in page.get("Snapshots", []):
                snap_id = snap.get("SnapshotId")
                tags = snap.get("Tags", [])
                name = next((t["Value"] for t in tags if t["Key"] == "Name"), snap_id)
                resources.append({
                    "id": snap_id,
                    "name": name,
                    "type": "ebs_snapshot",
                    "service": "EBS",
                    "status": "INCOMPLETE",
                    "issues": [],
                    "region": region,
                    "raw": {
                        "volume_id": snap.get("VolumeId"),
                        "start_time": snap.get("StartTime"),
                        "volume_size": snap.get("VolumeSize"),
                        "encrypted": snap.get("Encrypted"),
                        "description": snap.get("Description"),
                        "tags": tags,
                    },
                })
    except ClientError as e:
        raise ScannerError(str(e), resources) from e
    return resources
