from botocore.exceptions import ClientError
from exceptions import ScannerError


def scan(session, region="us-east-1"):
    resources = []
    try:
        ec2 = session.client("ec2", region_name=region)
        paginator = ec2.get_paginator("describe_volumes")
        for page in paginator.paginate():
            for volume in page.get("Volumes", []):
                vol_id = volume.get("VolumeId")
                tags = volume.get("Tags", [])
                name = next((t["Value"] for t in tags if t["Key"] == "Name"), vol_id)
                resources.append({
                    "id": vol_id,
                    "name": name,
                    "type": "ebs_volume",
                    "service": "EBS",
                    "status": "INCOMPLETE",
                    "issues": [],
                    "region": region,
                    "raw": {
                        "size": volume.get("Size"),
                        "state": volume.get("State"),
                        "encrypted": volume.get("Encrypted"),
                        "volume_type": volume.get("VolumeType"),
                        "attachments": volume.get("Attachments", []),
                        "tags": tags,
                        "create_time": volume.get("CreateTime"),
                    },
                })
    except ClientError as e:
        raise ScannerError(str(e), resources) from e
    return resources
